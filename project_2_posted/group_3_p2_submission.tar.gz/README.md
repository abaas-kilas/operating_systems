## Project #2  CSCI-4061 Fall 2022
 
 # Group Member #1: Abaas Kilas kilas002
 * Contribution: Preliminary, communication pipes and req_t commands, error checking/coding style
 
 # Group Member #2: Kirill Rakitin rakit006
 * Contribution: Preliminary, favorites management, error checking/coding style
 
 # Group Member #3: Jakob Robinson robi1456
 * Contribution: Preliminary, utils, URL handling, error checking/coding style